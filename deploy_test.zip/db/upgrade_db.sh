#!/bin/sh
echo $1 $2 >>deploy_db.log