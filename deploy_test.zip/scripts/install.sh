#!/bin/bash

echo $1 >>deploy_app.log